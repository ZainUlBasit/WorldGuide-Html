/* Initialize common javascript functions of UPG*/
jQuery(function ($) {
  //jQuery.fancybox.open('<div class="message"><h2>Hello!</h2><p>You are awesome!</p></div>');
  /*
    jQuery('[data-fancybox="images"]').fancybox({
      thumbs: {
        autoStart: true,
        axis: 'x'
      }
    })
  */
});

